
package com.ultrapro.pump

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Android 13+ notification permission
        if (Build.VERSION.SDK_INT >= 33) {
            val p = Manifest.permission.POST_NOTIFICATIONS
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(p), 1001)
            }
        }

        web = WebView(this)
        setContentView(web)

        initWebView()
        web.loadUrl("file:///android_asset/web/index.html")
    }

    private fun initWebView() {
        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.allowFileAccess = true
        s.allowContentAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        s.cacheMode = WebSettings.LOAD_DEFAULT

        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AndroidServiceBridge(), "AndroidService")
    }

    inner class AndroidServiceBridge {
        @JavascriptInterface fun start() { PumpMonitorService.start(this@MainActivity) }
        @JavascriptInterface fun stop() { PumpMonitorService.stop(this@MainActivity) }

        @JavascriptInterface fun lastAlert(): String {
            val sp = getSharedPreferences("pump_monitor", MODE_PRIVATE)
            return sp.getString("last_alert", "{}") ?: "{}"
        }

        @JavascriptInterface fun setBrain(jsonText: String): Boolean {
            return PumpMonitorService.installBrain(this@MainActivity, jsonText)
        }
    }
}
