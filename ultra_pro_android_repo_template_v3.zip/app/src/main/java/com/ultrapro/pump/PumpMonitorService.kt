
package com.ultrapro.pump

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class PumpMonitorService : Service() {

    // ---------------- WebSocket clients ----------------
    private val httpTicker by lazy {
        OkHttpClient.Builder().pingInterval(15, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    }
    private val httpRpc by lazy {
        OkHttpClient.Builder().pingInterval(15, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
    }

    private val exec = Executors.newSingleThreadExecutor()
    private val tickExec = Executors.newSingleThreadScheduledExecutor()

    private var wsTicker: WebSocket? = null
    private var wsRpc: WebSocket? = null
    private var rpcId = 1
    private val activeSubs = HashSet<String>()

    // ---------------- Brain runner (int16-quant JSON -> float) ----------------
    data class Layer(val rows:Int, val cols:Int, val W:FloatArray, val b:FloatArray)
    data class Net(val l1:Layer, val l2:Layer, val l3:Layer) {
        val h1 = l1.cols
        val h2 = l2.cols
        val buf1 = FloatArray(h1)
        val buf2 = FloatArray(h2)
    }
    data class Brain(
        val seed: Net,
        val heavy: Net,
        val seedTrigger: Double,
        val heavyThreshold: Double,
        val tracking: JSONObject
    )
    private var brain: Brain? = null

    private fun sigmoid(z: Double) = 1.0 / (1.0 + exp(-z))

    private fun forward(net: Net, x: FloatArray): Double {
        val h1 = net.h1
        val h2 = net.h2

        // buf1 = b1
        for (c in 0 until h1) net.buf1[c] = net.l1.b[c]
        // xW1
        for (r in 0 until net.l1.rows) {
            val xr = x[r]
            val base = r*h1
            var c=0
            while (c<h1) { net.buf1[c] += xr * net.l1.W[base+c]; c++ }
        }
        for (c in 0 until h1) if (net.buf1[c] < 0f) net.buf1[c] = 0f

        // buf2 = b2
        for (c in 0 until h2) net.buf2[c] = net.l2.b[c]
        // a1W2
        for (r in 0 until net.l2.rows) {
            val xr = net.buf1[r]
            if (xr == 0f) continue
            val base = r*h2
            var c=0
            while (c<h2) { net.buf2[c] += xr * net.l2.W[base+c]; c++ }
        }
        for (c in 0 until h2) if (net.buf2[c] < 0f) net.buf2[c] = 0f

        var z = net.l3.b[0].toDouble()
        var i=0
        while (i<h2) { z += net.buf2[i].toDouble() * net.l3.W[i].toDouble(); i++ }
        return sigmoid(z)
    }

    private fun readBrainJson(): JSONObject? {
        val f = File(filesDir, "brain_ultra_pro.json")
        if (!f.exists()) return null
        return try { JSONObject(f.readText(Charsets.UTF_8)) } catch (_:Throwable) { null }
    }

    private fun parseNet(obj: JSONObject, scale:Int): Net {
        val layers = obj.getJSONArray("layers")
        fun L(i:Int): Layer {
            val o = layers.getJSONObject(i)
            val rows = o.getInt("rows")
            val cols = o.getInt("cols")
            val Wj = o.getJSONArray("W")
            val bj = o.getJSONArray("b")
            val inv = 1f / scale.toFloat()
            val W = FloatArray(Wj.length())
            for (k in 0 until Wj.length()) W[k] = Wj.getInt(k).toFloat() * inv
            val b = FloatArray(bj.length())
            for (k in 0 until bj.length()) b[k] = bj.getInt(k).toFloat() * inv
            return Layer(rows, cols, W, b)
        }
        return Net(L(0), L(1), L(2))
    }

    private fun loadBrain() {
        val base = readBrainJson() ?: run { brain=null; return }
        try{
            val scale = base.getJSONObject("quant").getInt("scale")
            val seedObj = base.getJSONObject("seed").getJSONObject("netCalibrator")
            val heavyObj = base.getJSONObject("models").getJSONObject("heavy")
            val tracking = base.getJSONObject("tracking")

            val seed = parseNet(seedObj, scale)
            val heavy = parseNet(heavyObj, scale)

            val seedTrigger = seedObj.optDouble("fastTrigger", 0.82)
            val heavyThr = heavyObj.optDouble("threshold", 0.88)
            brain = Brain(seed, heavy, seedTrigger, heavyThr, tracking)
        }catch(_ : Throwable){
            brain=null
        }
    }

    // ---------------- Universe state (from miniTicker) ----------------
    data class U(
        var lastE: Long = 0L,
        var lastPrice: Double = 0.0,
        var lastV24: Double = 0.0,
        var muR: Double = 0.0, var vR: Double = 1e-6,
        var muV: Double = 0.0, var vV: Double = 1e-6,
        var retFast: Double = 0.0, var retSlow: Double = 0.0,
        var volFast: Double = 0.0, var volSlow: Double = 0.0,
        var volProxy: Double = 0.0,
        var hotSec: Double = 0.0,
        var coolUntil: Long = 0L,
        var tracking: Boolean = false
    )
    private val Umap = ConcurrentHashMap<String, U>()

    private fun ewUpdate(mu: Double, v: Double, x: Double, a: Double): Pair<Double, Double> {
        val d = x - mu
        val mu2 = mu + a*d
        val v2 = (1.0-a) * (v + a*d*d)
        return Pair(mu2, max(1e-9, v2))
    }
    private fun zscore(x: Double, mu: Double, v: Double): Double = (x - mu) / sqrt(max(1e-12, v))
    private fun ema(prev: Double, x: Double, dt: Double, tau: Double): Double {
        val a = 1.0 - exp(-dt / tau)
        return prev + a*(x - prev)
    }

    // ---------------- Tracking state (aggTrade + depth) ----------------
    data class Track(
        val symbol:String,
        val t0: Long,
        var lastPrice: Double = 0.0,
        var buyQ: Double = 0.0,
        var sellQ: Double = 0.0,
        var tradeCnt: Int = 0,
        var obImb: Double = 0.0,
        var spread: Double = 0.0,
        var liqSum: Double = 0.0,

        val N:Int = 480,
        var idx:Int = 0,
        var filled:Int = 0,
        val price: FloatArray = FloatArray(480),
        val buy: FloatArray = FloatArray(480),
        val sell: FloatArray = FloatArray(480),
        val tc: FloatArray = FloatArray(480),
        val ob: FloatArray = FloatArray(480),
        val spr: FloatArray = FloatArray(480),
        val liq: FloatArray = FloatArray(480),

        var lastEvalMs: Long = 0L,
        var pIdx:Int = 0,
        var pFilled:Int = 0,
        val probs: FloatArray = FloatArray(64),

        var rejected:Boolean = false,
        var alerted:Boolean = false,
        var lastAlertMs: Long = 0L,

        // proxies
        var rsi: Double = 50.0,
        var body: Double = 0.0,
        var wup: Double = 0.0,
        var wdn: Double = 0.0
    )
    private val Tmap = ConcurrentHashMap<String, Track>()
    private var lastHouse: Long = 0L
    private val globalAlertTimes = ArrayList<Long>()

    private fun clamp(x: Double, a: Double, b: Double): Double = max(a, min(b, x))

    private fun pushSecond(tr: Track) {
        val i = tr.idx
        tr.price[i] = tr.lastPrice.toFloat()
        tr.buy[i] = tr.buyQ.toFloat()
        tr.sell[i] = tr.sellQ.toFloat()
        tr.tc[i] = tr.tradeCnt.toFloat()
        tr.ob[i] = tr.obImb.toFloat()
        tr.spr[i] = tr.spread.toFloat()
        tr.liq[i] = tr.liqSum.toFloat()

        tr.buyQ = 0.0; tr.sellQ = 0.0; tr.tradeCnt = 0

        tr.idx = (i + 1) % tr.N
        tr.filled = min(tr.N, tr.filled + 1)
    }

    private fun at(buf: FloatArray, tr: Track, ago:Int): Double {
        if (tr.filled == 0) return 0.0
        val idx = tr.idx - 1 - ago
        val j = ((idx % tr.N) + tr.N) % tr.N
        return buf[j].toDouble()
    }
    private fun sum(buf: FloatArray, tr: Track, win:Int): Double {
        val n = min(win, tr.filled)
        var s=0.0
        for (a in 0 until n) s += at(buf, tr, a)
        return s
    }
    private fun mean(buf: FloatArray, tr: Track, win:Int): Double {
        val n = min(win, tr.filled)
        return if (n==0) 0.0 else sum(buf,tr,win)/n
    }
    private fun maxW(buf: FloatArray, tr: Track, win:Int): Double {
        val n = min(win, tr.filled)
        var m = -1e18
        for (a in 0 until n) { val v=at(buf,tr,a); if (v>m) m=v }
        return if (m==-1e18) 0.0 else m
    }
    private fun minW(buf: FloatArray, tr: Track, win:Int): Double {
        val n = min(win, tr.filled)
        var m = 1e18
        for (a in 0 until n) { val v=at(buf,tr,a); if (v<m) m=v }
        return if (m==1e18) 0.0 else m
    }
    private fun countSpikes(tr: Track, win:Int, thr: Double): Int {
        val n = min(win, tr.filled)
        if (n<=2) return 0
        var c=0
        var pPrev = at(tr.price, tr, win-1)
        for (a in win-2 downTo 0) {
            val p = at(tr.price, tr, a)
            if (pPrev>0) {
                val r = (p - pPrev)/pPrev
                if (abs(r) >= thr) c++
            }
            pPrev=p
        }
        return c
    }
    private fun corrRetVol(tr: Track, win:Int): Double {
        val n = min(win, tr.filled)
        if (n<=6) return 0.0
        var sumR=0.0; var sumV=0.0; var sumRR=0.0; var sumVV=0.0; var sumRV=0.0
        var pPrev = at(tr.price, tr, win-1)
        for (a in win-2 downTo 0) {
            val p = at(tr.price, tr, a)
            val v = at(tr.buy, tr, a) + at(tr.sell, tr, a)
            val r = if (pPrev>0) (p - pPrev)/pPrev else 0.0
            pPrev = p
            sumR += r; sumV += v
            sumRR += r*r; sumVV += v*v; sumRV += r*v
        }
        val mR = sumR/(n-1); val mV = sumV/(n-1)
        val cov = sumRV/(n-1) - mR*mV
        val vR  = sumRR/(n-1) - mR*mR
        val vV  = sumVV/(n-1) - mV*mV
        val denom = sqrt(max(1e-12, vR*vV))
        return clamp(cov/denom, -1.0, 1.0)
    }

    private fun heavyVector(tr: Track): FloatArray {
        val x = FloatArray(40)
        val p0 = at(tr.price,tr,0)
        val p5 = at(tr.price,tr,5)
        val p30 = at(tr.price,tr,30)
        val p60 = at(tr.price,tr,60)
        val p180 = at(tr.price,tr,180)

        val ret5 = if (p5>0) (p0-p5)/p5 else 0.0
        val ret30 = if (p30>0) (p0-p30)/p30 else 0.0
        val sl60 = if (p60>0) ((p0-p60)/p60)/60.0 else 0.0
        val sl180 = if (p180>0) ((p0-p180)/p180)/180.0 else 0.0

        val vol6 = sum(tr.buy,tr,6) + sum(tr.sell,tr,6)
        val vol36 = sum(tr.buy,tr,36) + sum(tr.sell,tr,36)

        val buy60 = sum(tr.buy,tr,60); val sell60 = sum(tr.sell,tr,60)
        val buy180 = sum(tr.buy,tr,180); val sell180 = sum(tr.sell,tr,180)
        val imb60 = if (buy60+sell60>0) (buy60-sell60)/(buy60+sell60) else 0.0
        val imb180 = if (buy180+sell180>0) (buy180-sell180)/(buy180+sell180) else 0.0

        val cvdNow = buy180 - sell180
        val cvdPrev = (sum(tr.buy,tr,360) - sum(tr.sell,tr,360))
        val cvdSlope = (cvdNow - cvdPrev)/180.0

        val obm = mean(tr.ob,tr,60)
        val ob0 = at(tr.ob,tr,0)
        val ob60 = at(tr.ob,tr,60)
        val obs = if (ob60!=0.0) (ob0-ob60)/60.0 else 0.0

        val sprm = mean(tr.spr,tr,60)
        val spr0 = at(tr.spr,tr,0)
        val spr60 = at(tr.spr,tr,60)
        val sprt = if (spr60!=0.0) (spr0-spr60)/60.0 else 0.0

        val hi = maxW(tr.price,tr,180)
        val lo = minW(tr.price,tr,180)
        val mid = (hi+lo)*0.5
        val rangeExp = if (mid>0) (hi-lo)/mid else 0.0
        val dd = if (hi>0) (hi-p0)/hi else 0.0

        val spikes = countSpikes(tr,180,0.0016)
        var micro=0.0
        for (a in 0 until min(10, tr.filled-1)) {
            val pA=at(tr.price,tr,a); val pB=at(tr.price,tr,a+1)
            if (pB>0) {
                val r=(pA-pB)/pB
                if (r>micro) micro=r
            }
        }

        val liq = mean(tr.liq,tr,10)
        val liq60 = mean(tr.liq,tr,60)
        val liqChange = liq - liq60

        val tc60 = sum(tr.tc,tr,60)
        val volCluster = if (vol6>0 && vol36>0) (vol6 / max(1e-9, vol36/6.0)) else 0.0
        val corr = corrRetVol(tr,180)

        val meanRev = clamp((dd - max(0.0, ret30))*4.0, 0.0, 1.0)
        val stall = if (abs(sl60) < 2e-5 && volCluster > 2.2) 1.0 else 0.0
        val whale = clamp((maxW(tr.buy,tr,60) + maxW(tr.sell,tr,60)) / max(1e-6, (vol36/36.0)), 0.0, 8.0) / 8.0
        val upCons = clamp((1.0 - (spikes/120.0)), 0.0, 1.0)
        val pullback = clamp(dd*3.0, 0.0, 1.0)
        val breakout = clamp(((p0 - hi*0.997)/max(1e-9, hi))*400.0, 0.0, 1.0)
        val overheat = clamp(((tr.rsi - 82.0)/18.0), 0.0, 1.0) + clamp(micro*25.0, 0.0, 1.0)
        val illiq = clamp((sprm*180.0), 0.0, 1.0) + (if (liq < 0.1) 1.0 else 0.0)
        val rejWick = clamp(tr.wup*1.2, 0.0, 1.0)

        val ageSec = (System.currentTimeMillis() - tr.t0)/1000.0
        val maxTrack = (brain?.tracking?.optInt("maxTrackSec", 420) ?: 420)
        val timeHot = clamp(ageSec / maxTrack.toDouble(), 0.0, 1.0)

        x[0]=1f
        x[1]=(clamp(ret5,-0.03,0.03)/0.03).toFloat()
        x[2]=(clamp(ret30,-0.08,0.08)/0.08).toFloat()
        x[3]=(clamp(sl60,-0.0012,0.0012)/0.0012).toFloat()
        x[4]=(clamp(sl180,-0.0007,0.0007)/0.0007).toFloat()
        x[5]=(clamp(vol6,0.0,5e4)/5e4).toFloat()
        x[6]=(clamp(vol36,0.0,2e5)/2e5).toFloat()
        x[7]=(clamp(vol6/1000.0,-6.0,6.0)/6.0).toFloat()
        x[8]=(clamp(vol36/4000.0,-6.0,6.0)/6.0).toFloat()
        x[9]=clamp(imb60,-1.0,1.0).toFloat()
        x[10]=clamp(imb180,-1.0,1.0).toFloat()
        x[11]=(clamp(cvdSlope,-2e4,2e4)/2e4).toFloat()
        x[12]=clamp(obm,-1.0,1.0).toFloat()
        x[13]=(clamp(obs,-0.02,0.02)/0.02).toFloat()
        x[14]=(clamp(sprm,0.0,0.02)/0.02).toFloat()
        x[15]=(clamp(sprt,-0.0003,0.0003)/0.0003).toFloat()
        x[16]=(clamp(tr.rsi,0.0,100.0)/100.0).toFloat()
        x[17]=0f
        x[18]=clamp(tr.body,0.0,1.0).toFloat()
        x[19]=clamp(tr.wup,0.0,1.0).toFloat()
        x[20]=clamp(tr.wdn,0.0,1.0).toFloat()
        x[21]=(clamp(rangeExp,0.0,0.15)/0.15).toFloat()
        x[22]=(clamp(dd,0.0,0.10)/0.10).toFloat()
        x[23]=timeHot.toFloat()
        x[24]=(clamp(spikes.toDouble(),0.0,40.0)/40.0).toFloat()
        x[25]=(clamp(micro,0.0,0.02)/0.02).toFloat()
        x[26]=(clamp(liq,0.0,3.0)/3.0).toFloat()
        x[27]=(clamp(liqChange,-1.5,1.5)/1.5).toFloat()
        x[28]=(clamp(tc60,0.0,3000.0)/3000.0).toFloat()
        x[29]=(clamp(volCluster,0.0,6.0)/6.0).toFloat()
        x[30]=corr.toFloat()
        x[31]=meanRev.toFloat()
        x[32]=stall.toFloat()
        x[33]=whale.toFloat()
        x[34]=upCons.toFloat()
        x[35]=pullback.toFloat()
        x[36]=breakout.toFloat()
        x[37]=(clamp(overheat,0.0,2.0)/2.0).toFloat()
        x[38]=(clamp(illiq,0.0,2.0)/2.0).toFloat()
        x[39]=rejWick.toFloat()
        return x
    }

    private fun pushProb(tr: Track, p: Double) {
        tr.probs[tr.pIdx] = p.toFloat()
        tr.pIdx = (tr.pIdx + 1) % tr.probs.size
        tr.pFilled = min(tr.probs.size, tr.pFilled + 1)
    }
    private fun countAbove(tr: Track, thr: Double, win: Int): Int {
        val n = min(win, tr.pFilled)
        var c=0
        for (i in 0 until n) {
            val idx = tr.pIdx - 1 - i
            val j = ((idx % tr.probs.size) + tr.probs.size) % tr.probs.size
            if (tr.probs[j].toDouble() >= thr) c++
        }
        return c
    }
    private fun countBelow(tr: Track, thr: Double, win: Int): Int {
        val n = min(win, tr.pFilled)
        var c=0
        for (i in 0 until n) {
            val idx = tr.pIdx - 1 - i
            val j = ((idx % tr.probs.size) + tr.probs.size) % tr.probs.size
            if (tr.probs[j].toDouble() <= thr) c++
        }
        return c
    }
    private fun pruneGlobalAlerts() {
        val win = 5*60*1000L
        val now = System.currentTimeMillis()
        globalAlertTimes.removeIf { now - it > win }
    }
    private fun canAlert(): Boolean {
        pruneGlobalAlerts()
        val maxA = brain?.tracking?.optInt("globalMaxAlertsPer5Min", 3) ?: 3
        return globalAlertTimes.size < maxA
    }

    private fun firePumpNotification(symbol: String, score: Double, price: Double, trackedSec: Int) {
        val chId = "pump_alerts"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(chId, "Pump Alerts", NotificationManager.IMPORTANCE_HIGH))
        }
        val n = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("هشدار پامپ: $symbol")
            .setContentText("امتیاز: ${"%.2f".format(score)} | قیمت: ${"%.6f".format(price)} | رصد: $trackedSec ثانیه")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)

        val sp = getSharedPreferences("pump_monitor", Context.MODE_PRIVATE)
        val obj = JSONObject()
        obj.put("symbol", symbol)
        obj.put("score", score)
        obj.put("price", price)
        obj.put("ts", System.currentTimeMillis())
        obj.put("trackedSec", trackedSec)
        sp.edit().putString("last_alert", obj.toString()).apply()
    }

    private fun startForegroundInternal() {
        val chId = "pump_monitor_bg"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(chId, "Market Monitor", NotificationManager.IMPORTANCE_LOW))
        }
        val notif = NotificationCompat.Builder(this, chId)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Ultra Pro — رصد پس‌زمینه فعال")
            .setContentText("پایش چند دقیقه‌ای + فیلتر سخت + هشدار کم ولی دقیق")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        startForeground(1001, notif)
    }

    // ---------------- RPC subscribe management ----------------
    private fun rpcSend(obj: JSONObject) { wsRpc?.send(obj.toString()) }
    private fun rpcSubscribe(streams: List<String>) {
        if (streams.isEmpty()) return
        val obj = JSONObject()
        obj.put("method","SUBSCRIBE")
        obj.put("params", JSONArray(streams))
        obj.put("id", rpcId++)
        rpcSend(obj)
        for (s in streams) activeSubs.add(s)
    }
    private fun rpcUnsubscribe(streams: List<String>) {
        if (streams.isEmpty()) return
        val obj = JSONObject()
        obj.put("method","UNSUBSCRIBE")
        obj.put("params", JSONArray(streams))
        obj.put("id", rpcId++)
        rpcSend(obj)
        for (s in streams) activeSubs.remove(s)
    }
    private fun syncSubs(wantedSyms: Set<String>) {
        val want = HashSet<String>()
        for (sym in wantedSyms) {
            want.add(sym.lowercase() + "@aggTrade")
            want.add(sym.lowercase() + "@depth10@100ms")
        }
        val toAdd = ArrayList<String>()
        val toDel = ArrayList<String>()
        for (s in want) if (!activeSubs.contains(s)) toAdd.add(s)
        for (s in activeSubs) if (!want.contains(s)) toDel.add(s)
        rpcUnsubscribe(toDel.take(800))
        rpcSubscribe(toAdd.take(800))
    }

    private fun housekeep() {
        val now = System.currentTimeMillis()
        if (now - lastHouse < 1200) return
        lastHouse = now
        val maxAge = (brain?.tracking?.optInt("maxTrackSec", 420) ?: 420) * 1000L
        val cool = (brain?.tracking?.optInt("perSymbolCooldownSec", 240) ?: 240) * 1000L

        val drop = ArrayList<String>()
        for ((sym, tr) in Tmap) {
            val age = now - tr.t0
            if (tr.rejected || age > maxAge) drop.add(sym)
        }
        for (sym in drop) {
            Tmap.remove(sym)
            Umap[sym]?.let { it.tracking=false; it.hotSec=0.0; it.coolUntil=now+cool }
        }

        val maxActive = brain?.tracking?.optInt("maxActive", 24) ?: 24
        val keep = Tmap.values.toList().sortedBy { it.t0 }.take(maxActive).map { it.symbol }.toSet()
        syncSubs(keep)
    }

    private fun evaluate(tr: Track) {
        val b = brain ?: return
        val now = System.currentTimeMillis()
        val evalEvery = b.tracking.optInt("evalEverySec", 3)
        if (now - tr.lastEvalMs < evalEvery*1000L) return
        tr.lastEvalMs = now

        val x = heavyVector(tr)
        val p = forward(b.heavy, x)
        pushProb(tr, p)

        val ageSec = ((now - tr.t0)/1000.0)
        val minAnalyze = b.tracking.optInt("minAnalyzeSec", 150)

        val rejBelow = b.tracking.optDouble("rejectBelow", 0.58)
        val rejWin = b.tracking.optInt("rejectWindow", 28)
        val rejNeed = b.tracking.optInt("rejectNeeded", 18)

        if (ageSec > minAnalyze) {
            val bad = countBelow(tr, rejBelow, rejWin)
            if (bad >= rejNeed) { tr.rejected=true; return }
        }

        val thr = b.heavyThreshold
        val susWin = b.tracking.optInt("sustainWindow", 24)
        val susNeed = b.tracking.optInt("sustainNeeded", 12)
        val cooldown = b.tracking.optInt("perSymbolCooldownSec", 240) * 1000L

        if (ageSec >= minAnalyze && !tr.alerted) {
            val good = countAbove(tr, thr, susWin)
            if (good >= susNeed && canAlert() && (now - tr.lastAlertMs) > cooldown) {
                tr.alerted=true
                tr.lastAlertMs=now
                globalAlertTimes.add(now)
                firePumpNotification(tr.symbol, p, tr.lastPrice, ageSec.roundToInt())
            }
        }
    }

    // ---------------- sockets ----------------
    private fun startTickerSocket() {
        val req = Request.Builder().url("wss://stream.binance.com:9443/ws").build()
        wsTicker = httpTicker.newWebSocket(req, object: WebSocketListener(){
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val sub = JSONObject()
                sub.put("method","SUBSCRIBE")
                sub.put("params", JSONArray().put("!miniTicker@arr"))
                sub.put("id", 1)
                webSocket.send(sub.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                exec.execute {
                    try{
                        val b = brain ?: return@execute
                        val arr = if (text.startsWith("[")) JSONArray(text)
                                  else JSONObject(text).optJSONArray("data") ?: return@execute
                        val now = System.currentTimeMillis()

                        // Seed gate from installed brain (ruleGate)
                        val base = readBrainJson() ?: return@execute
                        val rg = base.getJSONObject("seed").getJSONObject("ruleGate")
                        val minHotSec = rg.optDouble("minHotSec", 10.0)
                        val retAccelZ = rg.optDouble("retAccelZ", 1.65)
                        val volAccelZ = rg.optDouble("volAccelZ", 1.55)

                        for (i in 0 until arr.length()) {
                            val t = arr.getJSONObject(i)
                            val symbol = t.getString("s").uppercase()
                            if (!symbol.endsWith("USDT")) continue
                            if (symbol.contains("UPUSDT") || symbol.contains("DOWNUSDT") || symbol.contains("BULLUSDT") || symbol.contains("BEARUSDT")) continue

                            val price = t.getString("c").toDouble()
                            val v24 = t.getString("q").toDouble()

                            val st = Umap.getOrPut(symbol) { U() }
                            val dt = if (st.lastE>0) max(0.2, (now - st.lastE)/1000.0) else 1.0
                            val prevP = if (st.lastPrice>0) st.lastPrice else price
                            val ret = if (prevP>0) (price - prevP)/prevP else 0.0
                            val prevV = if (st.lastV24>0) st.lastV24 else v24
                            val volVel = (v24 - prevV)/dt

                            st.retFast = ema(st.retFast, ret, dt, 5.0)
                            st.retSlow = ema(st.retSlow, ret, dt, 30.0)
                            st.volFast = ema(st.volFast, volVel, dt, 6.0)
                            st.volSlow = ema(st.volSlow, volVel, dt, 36.0)
                            st.volProxy = ema(st.volProxy, abs(ret), dt, 18.0)

                            val upR = ewUpdate(st.muR, st.vR, st.retFast, 0.02); st.muR=upR.first; st.vR=upR.second
                            val upV = ewUpdate(st.muV, st.vV, st.volFast, 0.02); st.muV=upV.first; st.vV=upV.second

                            st.lastE = now
                            st.lastPrice = price
                            st.lastV24 = v24

                            Tmap[symbol]?.let { it.lastPrice = price }

                            if (now < st.coolUntil) continue
                            if (st.tracking) continue
                            if (Tmap.size >= b.tracking.optInt("maxActive", 24)) continue

                            val rzFast = zscore(st.retFast, st.muR, st.vR)
                            val rzSlow = zscore(st.retSlow, st.muR, st.vR)
                            val rzAcc = rzFast - rzSlow

                            val vzFast = zscore(st.volFast, st.muV, st.vV)
                            val vzSlow = zscore(st.volSlow, st.muV, st.vV)
                            val vzAcc = vzFast - vzSlow

                            val cond = (rzAcc > retAccelZ) && (vzAcc > volAccelZ)
                            st.hotSec = if (cond) min(600.0, st.hotSec + dt) else max(0.0, st.hotSec - 2.0*dt)

                            if (st.hotSec >= minHotSec) {
                                // seed vector (14)
                                val x = FloatArray(14)
                                x[0]=1f
                                x[1]=(clamp(rzFast,-6.0,6.0)/6.0).toFloat()
                                x[2]=(clamp(rzSlow,-6.0,6.0)/6.0).toFloat()
                                x[3]=(clamp(rzAcc,-6.0,6.0)/6.0).toFloat()
                                x[4]=(clamp(vzFast,-6.0,6.0)/6.0).toFloat()
                                x[5]=(clamp(vzSlow,-6.0,6.0)/6.0).toFloat()
                                x[6]=(clamp(vzAcc,-6.0,6.0)/6.0).toFloat()
                                x[7]=0f; x[8]=0f; x[9]=0f; x[10]=0f
                                x[11]=0f; x[12]=0f
                                x[13]=(clamp(st.volProxy,0.0,0.20)/0.20).toFloat()

                                val pSeed = forward(b.seed, x)
                                if (pSeed >= b.seedTrigger) {
                                    val tr = Track(symbol, now)
                                    tr.lastPrice = price
                                    Tmap[symbol] = tr
                                    st.tracking = true
                                    st.hotSec = 0.0
                                } else {
                                    st.coolUntil = now + 45_000
                                    st.hotSec = 0.0
                                }
                            }
                        }

                        housekeep()
                    }catch(_ : Throwable){}
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                exec.execute {
                    stopAllSockets()
                    Thread.sleep(900)
                    startAllSockets()
                }
            }
        })
    }

    private fun startRpcSocket() {
        val req = Request.Builder().url("wss://stream.binance.com:9443/ws").build()
        wsRpc = httpRpc.newWebSocket(req, object: WebSocketListener(){
            override fun onOpen(webSocket: WebSocket, response: Response) { activeSubs.clear() }

            override fun onMessage(webSocket: WebSocket, text: String) {
                exec.execute {
                    try{
                        val obj = JSONObject(text)
                        val e = obj.optString("e", "")
                        if (e == "aggTrade") {
                            val sym = obj.getString("s").uppercase()
                            val tr = Tmap[sym] ?: return@execute
                            if (tr.rejected) return@execute
                            val p = obj.getString("p").toDouble()
                            val q = obj.getString("q").toDouble()
                            val isBuy = !obj.getBoolean("m")
                            val quoteQty = p*q
                            tr.lastPrice = p
                            if (isBuy) tr.buyQ += quoteQty else tr.sellQ += quoteQty
                            tr.tradeCnt += 1
                        } else if (e == "depthUpdate") {
                            val sym = obj.getString("s").uppercase()
                            val tr = Tmap[sym] ?: return@execute
                            if (tr.rejected) return@execute
                            val bids = obj.getJSONArray("b")
                            val asks = obj.getJSONArray("a")
                            var sb=0.0; var sa=0.0
                            val nb = min(10, bids.length())
                            val na = min(10, asks.length())
                            for (i in 0 until nb) {
                                val it = bids.getJSONArray(i)
                                val p = it.getString(0).toDouble()
                                val q = it.getString(1).toDouble()
                                sb += p*q
                            }
                            for (i in 0 until na) {
                                val it = asks.getJSONArray(i)
                                val p = it.getString(0).toDouble()
                                val q = it.getString(1).toDouble()
                                sa += p*q
                            }
                            val denom = sb+sa
                            tr.obImb = if (denom>0) (sb-sa)/denom else 0.0
                            tr.liqSum = if (denom>0) denom / max(1e-12, tr.lastPrice) else 0.0
                            val bestBid = if (nb>0) bids.getJSONArray(0).getString(0).toDouble() else 0.0
                            val bestAsk = if (na>0) asks.getJSONArray(0).getString(0).toDouble() else 0.0
                            val mid = if (bestBid>0 && bestAsk>0) (bestBid+bestAsk)/2.0 else 0.0
                            tr.spread = if (mid>0) (bestAsk-bestBid)/mid else 0.0
                        }
                    }catch(_ : Throwable){}
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                exec.execute {
                    stopAllSockets()
                    Thread.sleep(900)
                    startAllSockets()
                }
            }
        })
    }

    private fun startAllSockets() {
        loadBrain()
        startTickerSocket()
        startRpcSocket()

        tickExec.scheduleAtFixedRate({
            try{
                exec.execute {
                    for ((_, tr) in Tmap) {
                        if (tr.rejected) continue
                        pushSecond(tr)
                        evaluate(tr)
                    }
                    housekeep()
                }
            }catch(_ : Throwable){}
        }, 1, 1, TimeUnit.SECONDS)
    }

    private fun stopAllSockets() {
        try { wsTicker?.close(1000, "stop") } catch (_:Throwable){}
        try { wsRpc?.close(1000, "stop") } catch (_:Throwable){}
        wsTicker=null
        wsRpc=null
        activeSubs.clear()
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundInternal()
        exec.execute { startAllSockets() }
    }

    override fun onDestroy() {
        stopAllSockets()
        tickExec.shutdownNow()
        exec.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(ctx: Context) {
            val i = Intent(ctx, PumpMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, PumpMonitorService::class.java))
        }
        fun installBrain(ctx: Context, jsonText: String): Boolean {
            return try {
                val f = File(ctx.filesDir, "brain_ultra_pro.json")
                f.writeText(jsonText, Charsets.UTF_8)
                true
            } catch (_:Throwable) { false }
        }
    }
}
