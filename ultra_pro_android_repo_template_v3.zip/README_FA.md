# Ultra Pro V2 — مدل سنگین + پس‌زمینه واقعی

- UI در WebView (فارسی)
- Foreground Service برای رصد ۲۴/۷
- Binance Public WS
- Brain جداست: `brain_ultra_pro_v2.json` (داخل Repo/ZIP قرار نده)

## بدون برنامه‌نویسی (فقط کلیک)
1) GitHub → New repository (Public)
2) محتوای ZIP را Extract و Upload کن
3) Actions → Build Debug APK → Run workflow
4) Artifacts → app-debug → دانلود APK → نصب

## داخل اپ
1) فایل Brain را در UI انتخاب کن (Upload)
2) Brain خودکار برای سرویس پس‌زمینه هم نصب می‌شود
3) «فعال‌سازی پس‌زمینه» را بزن
