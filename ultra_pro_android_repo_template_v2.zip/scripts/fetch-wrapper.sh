#!/usr/bin/env bash
set -euo pipefail
mkdir -p gradle/wrapper
if [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  echo "gradle-wrapper.jar already present"
  exit 0
fi
echo "Downloading gradle-wrapper.jar..."
TMP="$(mktemp -d)"
curl -L -o "$TMP/gradle.zip" "https://services.gradle.org/distributions/gradle-8.2-bin.zip"
unzip -q "$TMP/gradle.zip" -d "$TMP"
JAR="$(ls "$TMP/gradle-8.2/lib/plugins/" | grep -E 'gradle-wrapper-.*\.jar' | head -n 1)"
cp "$TMP/gradle-8.2/lib/plugins/$JAR" gradle/wrapper/gradle-wrapper.jar
echo "OK"
